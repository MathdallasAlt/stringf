This is a Python module providing some functions related to lists and strings.

Functions-
list_to_str(word):Convert a list into a string e.g. ['p','y','t','h','o','n']-'python'

join(word,word2):joins two words e.g. 'pyt','hon'-'python'

add(word,pos,word2):Like the join() functions but can join word after the letter at the specified position
e.g. add("bore",1,"ef")-'before'

reverse(word):Reverses a string 
e.g. reverse("python")-"nohtyp"

More functions coming soon!
